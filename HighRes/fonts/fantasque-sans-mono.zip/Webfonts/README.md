In order to use the included CSS rules, upload in the same folder the contents
of `Webfonts/` PLUS the `.ttf` files from the archive's root PLUS the `.otf`
files from the `OTF/` folder.
